using System;

class Dog:Animal
{
    string color="Black";

    public void Showclr()
    {
        Console.WriteLine(base.color);
        Console.WriteLine(color);
    }
}