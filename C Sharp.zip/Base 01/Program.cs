﻿using System;
class Program
{
    public static void Main(String[] args)
    {
        Console.WriteLine("----Base Class----");
        Console.WriteLine();

        Dog dg=new Dog();
        dg.Showclr();
    }
}