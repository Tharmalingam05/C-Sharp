using System;

class Animal
{
    public string color="White";
}