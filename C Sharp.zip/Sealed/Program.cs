﻿using System;
class Program
{
    public static void Main(String[] args)
    {
        Console.WriteLine("---Sealed Class---");
        Console.WriteLine();

        // Without using a Sealed Class

        Dog dg=new Dog();
        dg.eat();
        dg.bark();

        // Now using a Sealed Class
    }
}