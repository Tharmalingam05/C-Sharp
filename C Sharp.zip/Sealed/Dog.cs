using System;
class Dog:Animal
{
    public void bark()
    {
        Console.WriteLine("Barking....");
    }
}