using System;

sealed class Animal
{
    public void eat()
    {
        Console.WriteLine("Eating...");
    }
}