using System.Collections.Generic;
using System;

class AnoMat
{
    public void Display()
    {
        List<String>name=new List<string>(){"Santhosh","Sanjay","Saravana"};

        foreach(String str in name)
        {
            Console.WriteLine(str);
        }
    }
}