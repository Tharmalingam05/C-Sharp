﻿using System.Collections.Generic;
using System.Data;
using System.Resources;
using System;

class Program
{
    public static void Main(String[] args)
    {
        Console.WriteLine("---List In Csharp---");
        Console.WriteLine();

        List<string>names=new List<string>();
        names.Add("Aravinth");
        names.Add("Dinesh");
        names.Add("Santhosh");
        names.Add("Praveen");

        foreach(string s in names)
        {
            Console.WriteLine(s);
        }

        Console.WriteLine("------------");

        AnoMat an=new AnoMat();
        an.Display();
    }
}