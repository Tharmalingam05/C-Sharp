﻿using System;
class Program
{
    public static void Main(String[] args)
    {
        Console.WriteLine("----Method Overloading----");
        Console.WriteLine();

        Console.Write("Enter a F-Number :");
        int a=Convert.ToInt32(Console.ReadLine());

        Console.Write("Enter a S-Number :");
        int b=Convert.ToInt32(Console.ReadLine());

        Console.WriteLine(Cal.add(a,b));
        Console.WriteLine(Cal.add(a,b,5));

        Console.WriteLine("-------------------");

        Console.WriteLine(Calc.add_value(30,20));
        Console.WriteLine(Calc.add_value(5f,2f));
    }
}