using System;
class Cal 
{
    public static int add(int a,int b)
    {
        int res=a+b;
        Console.Write("Add value :");
        return res;
    }

    public static int add(int a,int b,int c)
    {
        int res=a-b-c;
        Console.Write("Sub value :");
        return res;
    }
}