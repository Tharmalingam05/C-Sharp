using System;

class Calc
{
    public static int add_value(int k ,int l)
    {
        return k+l;
    }

    public static float add_value(float s,float j)
    {
        return s-j;
    }
}