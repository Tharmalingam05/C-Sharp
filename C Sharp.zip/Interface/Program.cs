﻿using System;
class Program
{
    public static void Main(String[] args)
    {
        Console.WriteLine("---Interface---");
        Console.WriteLine();

        Circle cl=new Circle();
        cl.Draw_cir();

        // Doubt
    }
}