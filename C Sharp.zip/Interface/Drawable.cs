using System;
interface  Drawable
{
    public void Draw()
    {
        Console.WriteLine("Drawing...");
    }
}