using System;
class Circle:Drawable
{
    public void Draw_cir()
    {
        Console.WriteLine("Circle Drawing....");
    }
}