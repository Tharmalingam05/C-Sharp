﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Array
{
    internal class Arr
    {
        public static void arr(int[] arr)
        {
            Console.WriteLine("Enter a Array Elements :");

            for(int i=1;i<=arr.Length;i++)
            {
                Console.WriteLine(arr[i]);
            }
        }
    }
}
