﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Array
{
    internal class Jagged
    {
        public void jag()
        {
            int[][] arr = new int[2][];

            arr[0]=new int[] {1,2,3,4,5};
            arr[1] = new int[] { 11, 22, 33, 44, 55 };

            for(int i=0;i<arr.Length;++i)
            {
                for(int j = 0; j < arr[i].Length;j++)
                {
                    Console.Write(arr[i][j] + " ");
                }
                Console.WriteLine();
            }
        }
    }
}
