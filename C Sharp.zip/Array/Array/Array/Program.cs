﻿using Array;
using System;
using System.Collections.Generic;

class Program
{
    public static void Main(String[] args)
    {
        /*int[] arr1 ={1, 2, 3, 4, 5};
        int[] arr2 = {1, 2, 3, 4,9,7,8};

        Arr.arr(arr2);
        Arr.arr(arr1);*/

        /*  DDrry obj = new DDrry();
          obj.DD();*/

        Jagged ob = new Jagged();
        ob.jag();

    }
}