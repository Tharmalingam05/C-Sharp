﻿using System;
class Program
{
    public static void Main(String[] args)
    {
        Console.WriteLine("----POLYMORHISM----");
        Console.WriteLine();

        Dog dg=new Dog();
        dg.eat();

        Console.WriteLine();

        Console.WriteLine("-----------------");
        Console.WriteLine("Run Time Polymorphism nd derving two class");

        // Shapes sp=new Shapes();
        // sp.Draw();

        Shapes sp;

        sp=new Shapes();
        sp.Draw();

        sp=new Rectangle();
        sp.Draw();

        sp=new Circle();
        sp.Draw();
    }
}