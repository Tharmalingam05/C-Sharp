using System;

class Animal
{
    public virtual void eat()
    {
        Console.WriteLine("Eating---");
    }
}