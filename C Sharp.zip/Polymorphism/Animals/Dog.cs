using System;

class Dog:Animal
{
    public override void eat()
    {
        Console.WriteLine("Bread Eating....");
    }
}