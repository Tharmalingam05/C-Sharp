using System;
class Rectangle:Shapes
{
    public override void Draw()
    {
        Console.WriteLine("Drawing Rectangle....");
    }
}