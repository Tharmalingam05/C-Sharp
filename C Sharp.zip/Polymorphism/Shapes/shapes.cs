using System;
class Shapes
{
    public virtual void Draw()
    {
        Console.WriteLine("Drawing....");
    }
}