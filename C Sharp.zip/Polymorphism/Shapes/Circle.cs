using System;
class Circle:Shapes
{
    public override void Draw()
    {
        Console.WriteLine("Circle Drawing....");
    }
}