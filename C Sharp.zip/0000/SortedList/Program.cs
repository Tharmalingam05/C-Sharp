﻿using System;
using System.Collections.Generic;

class Program
{
    public static void Main(String[] args)
    {
        Console.WriteLine("---Sorted List in C-Sharp");
        Console.WriteLine();

        SortedList<String,String>names=new SortedList<string, string>();
        names.Add("1","Santhosh");
        names.Add("2","Praveen");
        names.Add("3","Senthil");
        names.Add("4","Santhosh");

        foreach(KeyValuePair<string,string> kv in names)
        {
            Console.WriteLine(kv.Key+" "+kv.Value);
        }
    }
}