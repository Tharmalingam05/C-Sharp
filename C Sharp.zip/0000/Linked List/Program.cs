﻿using System;
using System.Collections.Generic;

class Program
{
    public static void Main(String[] args)
    {
        Console.WriteLine("---LinkedList in C-Sharp---");
        Console.WriteLine();

        LinkedList<String>names=new LinkedList<string>();
        names.AddLast("Sonnu");
        names.AddLast("Amkirt");
        names.AddLast("Badmin");
        names.AddLast("Seuard");
        names.AddFirst("Master");
        // It will consider first element and it will allows duplicate element in list.

        foreach(string str in names)
        {
            Console.WriteLine(str);
        }

        Console.WriteLine("\n----------------");
        Console.WriteLine("---Value insert (Before and After) in Linked List");

        Insert_Elem ins=new Insert_Elem();
        ins.Display();

    }
}