using System;
using System.Collections.Generic;

class Insert_Elem
{
    public void Display()
    {
        LinkedList<String>name=new LinkedList<string>();
        name.AddLast("Santhosh");
        name.AddLast("Senthil");
        name.AddLast("Lacy Joe");
        name.AddLast("Sonnu");

        //Insert new elements Before and after value.
        LinkedListNode<String> node=name.Find("Senthil");
        name.AddBefore(node,"Jhon");
        name.AddAfter(node,"Bursly");

        foreach(string st in name)
        {
            Console.WriteLine(st);
        }
    }
}