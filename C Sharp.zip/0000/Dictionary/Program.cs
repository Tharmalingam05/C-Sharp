﻿using Internal;
using System;
using System.Collections.Generic;

class Program
{
    public static void Main(String[] args)
    {
        Console.WriteLine("---Dictionary in C-Sharp---");
        Console.WriteLine();

        Dictionary<int,string>names=new Dictionary<int, string>();
        names.Add(1,"Santhosh");
        names.Add(2,"Senthil");
        names.Add(3,"Praveen");
        names.Add(4,"Naidu");

        foreach(KeyValuePair<int,string> kvp in names)
        {
            Console.WriteLine(kvp);
        }

        Console.WriteLine("----------------");
                                                                                                                                      
        foreach(KeyValuePair<int,string> kvp in names)
        {
            Console.WriteLine(kvp.Key +" "+kvp.Value);
        }
    }
}