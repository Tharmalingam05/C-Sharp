﻿using System;
using System.Collections.Generic;
class Program
{
    public static void Main(String[] args)
    {
        Console.WriteLine("---Sorted List in C-Sharp---");
        Console.WriteLine();

        SortedDictionary<int,string>name=new SortedDictionary<int, string>();
        name.Add(1,"Santhosh");
        name.Add(2,"Praveen");
        name.Add(3,"Senthil");

        foreach(KeyValuePair<int,string>kv in name)
        {
            Console.WriteLine(kv.Key+" "+kv.Value);
        }
    }
}