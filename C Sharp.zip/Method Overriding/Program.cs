﻿using System;

class Program
{
    public static void Main(String[] args)
    {
        Console.WriteLine("----Method Overriding----");
        Console.ReadLine();

        BabyDog ob=new BabyDog();
        ob.eat();
    }
}