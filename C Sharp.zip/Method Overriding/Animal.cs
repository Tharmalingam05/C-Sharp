using System;

class Animals
{
    public virtual void eat()
    {
        Console.WriteLine("Eating....");
    }
}