using System;

class BabyDog:Animals
{
    public override void eat()
    {
        base.eat();
    }
}