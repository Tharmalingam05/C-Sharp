using System;

class Account
{
    int id;
    String name;
    static float rateOf=8.0F;

    public Account(int id,string name)
    {
        this.id=id;
        this.name=name;
    }
    static Account()
    {
        rateOf=0.9f;
    }
    public void Display()
    {
        Console.WriteLine(id+" "+name+" "+rateOf);
    }
}