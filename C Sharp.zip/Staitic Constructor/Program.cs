﻿using System;

class Program
{
    public static void Main(String[] args)
    {
        Console.WriteLine("----STATIC CONSTRUCTOR----");

        Console.WriteLine();

        Account ob1=new Account(7208,"Santhsoh");
        Account ob2=new Account(7209,"Aravinth");

        ob1.Display();
        ob2.Display();

    }
}