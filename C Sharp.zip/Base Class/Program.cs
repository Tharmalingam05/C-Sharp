﻿using Internal;
using System;
class Program
{
    public static void Main(String[] args)
    {
        Console.WriteLine("---Base Class---");
        Console.WriteLine();

        Console.WriteLine("Base class constructor is internally invoked");

        Dog dg=new Dog();

        Console.WriteLine("------------------");
        
    }
}