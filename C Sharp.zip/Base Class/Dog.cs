using System;

class Dog:Animal
{
    //Base class constructor is internally invoked.
    public Dog()
    {
        Console.WriteLine("Doging....");
    }
}