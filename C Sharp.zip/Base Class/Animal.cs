using System;

class Animal
{
    // Base class constructor is internally invoked.
    public Animal()
    {
        Console.WriteLine("Animal....");
    }
}