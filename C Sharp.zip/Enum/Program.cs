﻿using System;
namespace ENUM;
class Program
{
    enum Sessions{Winter,Spring,Antuun,Summer,Fall}
    public static void Main(String[] args)
    {
        Console.WriteLine("----Enumeration----");
        Console.WriteLine();

        int x=(int)Sessions.Winter;
        int y=(int)Sessions.Antuun;

        Console.WriteLine($"Winter Index Position :{x}");
        Console.WriteLine($"Antum Index Position :{y}");

    }
}