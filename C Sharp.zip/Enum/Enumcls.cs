using System;

class Program
{
    enum Sessions{Winter,Spring,Antuun,Summer,Fall}

    
}
