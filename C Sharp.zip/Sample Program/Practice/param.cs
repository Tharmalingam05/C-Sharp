using System;

internal class Param
{
    public void parms(params int[] arr)
    {
        for(int i=0;i<arr.Length;i++)
        {
            Console.Write(arr[i]+" ");
        }
    }
}