﻿using System;
using System.Collections.Generic;
class Program
{
    public static void Main(String[] args)
    {
        /*Paradigm ob=new Paradigm();
        ob.Params(12,23,34,45,56,54,323,45,65);

        Param ob1=new Param();
        ob1.parms(45,56,3,2,21,34);*/

        int[] arr1=new int[6]{12,34,45,67,78,89};
        int[] arr2=new int[6];

        Console.WriteLine("Array Length :"+arr1.Length);

        Array.Sort(arr1);
        Console.WriteLine("Sorting Array :"+arr1);

        Console.WriteLine("Finding index number :"+Array.IndexOf(arr1,45));

        Console.WriteLine("------------------------------------");

        Arrays ob=new Arrays();
        ob.Arr(arr2);


    }
}