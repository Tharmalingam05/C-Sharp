using System;

internal class Paradigm
{
    public static void Params(params int[] arr)
    {
        Console.WriteLine("Enter a Array values :");

        for(int i=0;i<arr.Length;i++)
        {
                Console.Write(arr[i]+" ");
        }
    }
}