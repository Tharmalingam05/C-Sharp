using System;
class Arrays
{
    public void Arr(int[] arr)
    {
        for(int i=0;i<arr.Length;i++)
        {
            Console.Write(arr[i]);
        }
    }
}