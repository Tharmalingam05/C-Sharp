﻿using System.Net.WebSockets;
using System;
using System.Collections.Generic;

class Program
{
    public static void Main(String[] args)
    {
        Console.WriteLine("I'm Santhosh");
    }
}