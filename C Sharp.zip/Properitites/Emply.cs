using System.Dynamic;
using System;

class Emply 
{
    // While Setting value.
    private string EmpName;

    public string Emp_Name
    {
        get
        {
            return EmpName;
        }
        set
        {
            EmpName=value+" JavaPoint";
        }
    }
}