﻿using System;
class Program
{
    public static void Main(String[] args)
    {
        Console.WriteLine("----PROPERITIES----");
        Console.WriteLine();

        Employee emp=new Employee();
        emp.Name="Santhosh";
        Console.WriteLine(emp.Name);

        Console.WriteLine("----Setting Value----");

        Emply em=new Emply();
        em.Emp_Name="Samson";
        Console.WriteLine(em.Emp_Name);

        Console.WriteLine("----Read Only Property----");

        Counter cnt1=new Counter();
        Counter cnt2=new Counter();
        Counter cnt3=new Counter();

        Console.WriteLine(Counter.Count);
        
    }
}