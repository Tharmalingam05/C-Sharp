using System;

class Counter
{
    // Read only Property
    private static  int count=0;
    public Counter()   // Constructor
    {
        count++;
    }

    public static int Count
    {
        get
        {
            return count;
        }
    }
}