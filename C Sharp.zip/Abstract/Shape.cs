using System;

abstract class Shape
{
    public abstract void draw();
}