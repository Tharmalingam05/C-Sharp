using System;
class Circle:Shape
{
    public override void draw()
    {
        Console.WriteLine("Circle Drawing....");
    }
}