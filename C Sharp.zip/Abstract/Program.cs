﻿using System;
class Program
{
    public static void Main(String[] args)
    {
        Console.WriteLine("---Abstract Method---");
        Console.WriteLine();

        Circle cr=new Circle();
        cr.draw();
    }
}